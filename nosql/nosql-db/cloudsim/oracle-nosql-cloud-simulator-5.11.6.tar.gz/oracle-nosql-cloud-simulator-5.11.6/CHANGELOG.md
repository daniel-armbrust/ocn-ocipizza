# Change Log
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/).

## 1.2.0 - 2020-02-11

### Changed
- Updated to bundle the 19.3 release of Oracle NoSQL Database
- Supports the protocol used by the updated Oracle NoSQL Database
Cloud Service that supports OCI native functionality.

### Removed
- The simulator is no longer an *SDK* and no longer includes examples and
driver documentation. Examples and documentation are now in the
language-specific SDKs.

## 18.227  - 2018-08-15
This was the initial release of the Oracle NoSQL Database Cloud Simulator.
This release was named as an *SDK* and included examples and documentation.
